# Copyright 2020 wrnch, Inc.
# All rights reserved.

import json
from http import HTTPStatus

import requests

from .constants import API_URL, INPUT_KEYS
from .endpoints import API_PATHS
from .exceptions import APIException, ClientException
from .joint_definitions import JOINT_DEFINITION_DEFAULTS, JOINT_DEFINITIONS
from .utils import wait_until


class wrCloud:
    def __init__(self, username=None, password=None, api_key=None, api_url=API_URL):
        self.username = username
        self.password = password
        self.api_key = api_key
        self.api_url = api_url
        self.auth_token = self.get_auth_token()

    def get_auth_token(self):
        data = {'username': self.username, 'password': self.password}
        if self.api_key is not None:
            data = {'api_key': self.api_key}

        resp = requests.post(url=self.api_url + API_PATHS['auth'], data=data)

        if resp.status_code != HTTPStatus.OK:
            message = self._get_api_message(resp)
            raise APIException(message)

        return resp.json()['access_token']

    def update_auth_token(self):
        self.auth_token = self.get_auth_token()

    def authed(self, request, *args, **kwargs):
        kwargs['headers'] = {
            'Authorization': 'Bearer {}'.format(
                self.auth_token)}
        kwargs['url'] = self.api_url + kwargs['path']
        kwargs.pop('path')
        resp = request(*args, **kwargs)
        if resp.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
            self.update_auth_token()
            kwargs['headers'] = {
                'Authorization': 'Bearer {}'.format(
                    self.auth_token)}
            resp = request(*args, **kwargs)

        return resp

    def submit_job(self, filename, work_type=['annotated_media'],
                   options={}, url=False):
        # TODO: Reject fbx job if the file is not a video
        if isinstance(work_type, str):
            work_type = [work_type]
        if not all(key in INPUT_KEYS for key in work_type):
            raise ClientException('Invalid work type.')
        options['work_type'] = work_type
        if url:
            options['media'] = filename
            resp = self.authed(
                requests.post,
                path=API_PATHS['jobs'],
                data=options)
        else:
            with open(filename, 'rb') as f:
                resp = self.authed(requests.post,
                                   path=API_PATHS['jobs'],
                                   data=options,
                                   files={'media': f})

        if resp.status_code != HTTPStatus.ACCEPTED:
            message = self._get_api_message(resp)
            raise APIException(message)

        return resp.json()['job_id']

    def get_job_status(self, job_id):
        path = API_PATHS['status'].format(job_id=job_id)
        resp = self.authed(requests.get, path=path)

        if resp.status_code != HTTPStatus.OK:
            message = self._get_api_message(resp)

            if resp.status_code == HTTPStatus.NOT_FOUND:
                message = 'Invalid job ID'

            raise APIException(message)

        return resp.json()

    def get_job_details(self, job_id):
        path = API_PATHS['details'].format(job_id=job_id)
        resp = self.authed(requests.get, path=path)

        if resp.status_code != HTTPStatus.OK:
            message = self._get_api_message(resp)

            if resp.status_code == HTTPStatus.NOT_FOUND:
                message = 'Invalid job ID'

            raise APIException(message)

        return resp.json()

    def is_job_successful(self, job_id):
        status = self.get_job_status(job_id)

        return status == 'Processed'

    def is_job_processed(self, job_id):
        status = self.get_job_status(job_id)

        return status == 'Processed' or status == 'Error'

    def wait_for_processed_job(self, job_id, interval=10, timeout=250):
        wait_until(
            lambda: self.is_job_processed(job_id),
            interval=interval,
            timeout=timeout)

    def get_last_50_job_status(self, page_number=0):
        path = API_PATHS['status_list_50'].format(page_number=page_number)
        resp = self.authed(requests.get, path=path)

        if resp.status_code != HTTPStatus.OK or not isinstance(
                resp.json(), dict):
            message = self._get_api_message(resp)
            raise APIException(message)

        return resp.json()

    def get_all_jobs(self):
        resp = self.authed(requests.get, path=API_PATHS['jobs'])

        if resp.status_code != HTTPStatus.OK or not isinstance(
                resp.json(), list):
            message = self._get_api_message(resp)
            raise APIException(message)

        return resp.json()

    def _get_processed_result(self, job_id, work_type):
        work_type = '?work_type=' + work_type if work_type else work_type
        path = API_PATHS['job'].format(job_id=job_id, work_type=work_type)
        resp = self.authed(requests.get, path=path, stream=True)

        if resp.status_code != HTTPStatus.OK:
            message = ''
            if resp.status_code == HTTPStatus.NOT_FOUND:
                message = resp.json()['message']
            raise APIException(message)
        return resp

    def download_job(self, job_id, output_path, work_type=''):
        resp = self._get_processed_result(job_id, work_type)
        with open(output_path, 'wb') as f:
            for chunk in resp:
                f.write(chunk)

    def get_result_as_string(self, job_id, work_type=''):
        resp = self._get_processed_result(job_id, work_type)
        return resp.text

    def get_json_result_as_dict(self, job_id):
        output = self.get_result_as_string(job_id, 'json')
        try:
            return json.loads(output)
        except json.decoder.JSONDecodeError:
            raise APIException('Unable to parse the result. Please make sure this job has a JSON output.')

    def _get_api_message(self, resp):
        try:
            message = resp.json()['message']
        except BaseException:
            message = resp.text

        return message

    @staticmethod
    def get_joint_definition(joint_format_name):
        try:
            return JOINT_DEFINITIONS[joint_format_name]
        except KeyError:
            raise ClientException(
                "Unknown joint definition: {}".format(joint_format_name))

    @staticmethod
    def get_default_joint_definition(pose_type='pose2d'):
        try:
            return JOINT_DEFINITION_DEFAULTS[pose_type]
        except KeyError:
            raise ClientException("Unknown pose type: {}".format(pose_type))

    @staticmethod
    def get_all_default_joint_definitions():
        return JOINT_DEFINITION_DEFAULTS
