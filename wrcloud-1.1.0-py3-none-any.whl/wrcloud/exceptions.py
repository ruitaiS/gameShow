# Copyright 2020 wrnch, Inc.
# All rights reserved.


class wrCloudException(Exception):
    pass


class APIException(wrCloudException):
    pass


class ClientException(wrCloudException):
    pass
