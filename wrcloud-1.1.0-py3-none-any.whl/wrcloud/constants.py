# Copyright 2020 wrnch, Inc.
# All rights reserved.
from collections import namedtuple

INPUT_KEYS = {
    'annotated_media': 'media',
    'fbx': 'media',
    'json': 'media'
}

API_URL = 'https://api.wrnch.ai'

Joints = namedtuple('Joints', ['name', 'joint_names', 'bone_pairs'])

J25_JOINTS = Joints(
    name='j25',
    joint_names=[
        'RANKLE', 'RKNEE', 'RHIP', 'LHIP', 'LKNEE', 'LANKLE', 'PELV',
        'THRX', 'NECK', 'HEAD', 'RWRIST', 'RELBOW', 'RSHOULDER', 'LSHOULDER',
        'LELBOW', 'LWRIST', 'NOSE', 'REYE', 'REAR', 'LEYE', 'LEAR', 'RTOE',
        'LTOE', 'RHEEL', 'LHEEL'],
    bone_pairs=[
        (0, 1), (1, 2), (5, 4), (4, 3), (2, 3), (2, 12), (3, 13),
        (12, 13), (13, 14), (14, 15), (12, 11), (11, 10), (5, 22),
        (0, 21), (5, 24), (0, 23)]
)

EXTENDED_JOINTS = Joints(
    name='extended',
    joint_names=[
        'PELV', 'LHIP', 'LKNEE', 'LANKLE', 'RHIP', 'RKNEE', 'RANKLE',
        'SPINE0', 'LSHOULDER', 'LELBOW', 'LWRIST', 'RSHOULDER', 'RELBOW',
        'RWRIST', 'HEAD', 'LTOE', 'RTOE', 'LCOLLAR', 'RCOLLAR', 'NECK',
        'SPINE1', 'SPINE2', 'LHIP_ROLL', 'LKNEE_ROLL', 'RHIP_ROLL',
        'RKNEE_ROLL', 'LSHOULDER_ROLL', 'LELBOW_ROLL', 'RSHOULDER_ROLL', 'RELBOW_ROLL'],
    bone_pairs=[
        (22, 1), (2, 1), (15, 3), (3, 2), (23, 2), (1, 0), (24, 4), (5, 4),
        (16, 6), (6, 5), (25, 5), (4, 0), (14, 19), (19, 21), (26, 8),
        (27, 9), (10, 9), (9, 8), (8, 17), (17, 21), (28, 11), (29, 12),
        (13, 12), (12, 11), (11, 18), (18, 21), (21, 20), (20, 7), (7, 0)]
)

FACE20_JOINTS = Joints(
    name='wrFace20',
    joint_names=[
        'CHIN', 'LCHEEK', 'LLEYE', 'LLEYEBROW', 'LMCHEEK', 'LMEYEBROW',
        'LMOUTH', 'LREYE', 'LREYEBROW', 'NOSEBRIDGE', 'NOSETIP', 'RCHEEK',
        'RLEYE', 'RLEYEBROW', 'RMCHEEK', 'RMEYEBROW', 'RMOUTH', 'RREYE',
        'RREYEBROW', 'TOPMOUTH'],
    bone_pairs=[
        (9, 10), (10, 19), (10, 1), (10, 11), (19, 6), (19, 16),
        (16, 0), (6, 0), (6, 4), (16, 14), (9, 8), (9, 7), (9, 13),
        (9, 12), (8, 5), (13, 15), (5, 3), (15, 18), (7, 2), (12, 17)]
)

HAND21_JOINTS = Joints(
    name='hand21',
    joint_names=[
        'Wrist', 'TMCP', 'IMCP', 'MMCP', 'RMCP', 'PMCP', 'TPIP', 'TDIP',
        'TTIP', 'IPIP', 'IDIP', 'ITIP', 'MPIP', 'MDIP', 'MTIP', 'RPIP',
        'RDIP', 'RTIP', 'PPIP', 'PDIP', 'PTIP'],
    bone_pairs=[
        (0, 1), (1, 6), (6, 7), (7, 8), (0, 2), (2, 9), (9, 10),
        (10, 11), (0, 3), (3, 12), (12, 13), (13, 14), (0, 4), (4, 15),
        (15, 16), (16, 17), (0, 5), (5, 18), (18, 19), (19, 20)]
)
