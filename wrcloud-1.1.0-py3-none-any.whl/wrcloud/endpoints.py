# Copyright 2020 wrnch, Inc.
# All rights reserved.

API_PATHS = {
    "auth": "/v1/login",
    "details": "/v1/details/{job_id}",
    "jobs": "/v1/jobs",
    "job": "/v1/jobs/{job_id}{work_type}",
    "status": "/v1/status/{job_id}",
    "status_list_50": "/v1/status?page={page_number}"
}
