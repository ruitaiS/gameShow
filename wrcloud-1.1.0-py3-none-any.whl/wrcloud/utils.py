# Copyright 2020 wrnch, Inc.
# All rights reserved.

import time


def wait_until(condition, interval=1, timeout=10, *args):
    start = time.time()
    while (time.time() - start) < timeout:
        if condition(*args):
            return

        time.sleep(interval)

    assert False, 'Condition timeout'
