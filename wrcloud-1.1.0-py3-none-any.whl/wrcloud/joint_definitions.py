from collections import defaultdict

from .constants import (EXTENDED_JOINTS, FACE20_JOINTS, HAND21_JOINTS,
                        J25_JOINTS)


class JointDefinition:
    def __init__(self, name, joint_names, bone_pairs):
        self.name = name
        self._bone_pairs = bone_pairs
        self._joint_names = self.from_ordered_list_to_dict(joint_names)

    def get_bone_pairs(self):
        return self._bone_pairs

    def get_bone_map(self):
        return self.from_pairs_to_dict(self._bone_pairs)

    def get_joints(self):
        return self._joint_names

    def get_joint_list(self):
        ordered_joints = sorted(
            self._joint_names.keys(),
            key=lambda joint: self._joint_names[joint])
        return list(ordered_joints)

    @staticmethod
    def from_ordered_list_to_dict(ordered_list):
        result_dict = {}
        for i, item in enumerate(ordered_list):
            result_dict[item] = i

        return result_dict

    @staticmethod
    def from_pairs_to_dict(pairs):
        result_dict = defaultdict(set)
        for item1, item2 in pairs:
            result_dict[item1].add(item2)
            result_dict[item2].add(item1)

        return result_dict


J25 = JointDefinition(
    name=J25_JOINTS.name,
    joint_names=J25_JOINTS.joint_names,
    bone_pairs=J25_JOINTS.bone_pairs)

EXTENDED = JointDefinition(
    name=EXTENDED_JOINTS.name,
    joint_names=EXTENDED_JOINTS.joint_names,
    bone_pairs=EXTENDED_JOINTS.bone_pairs)

FACE20 = JointDefinition(
    name=FACE20_JOINTS.name,
    joint_names=FACE20_JOINTS.joint_names,
    bone_pairs=FACE20_JOINTS.bone_pairs)

HAND21 = JointDefinition(
    name=HAND21_JOINTS.name,
    joint_names=HAND21_JOINTS.joint_names,
    bone_pairs=HAND21_JOINTS.bone_pairs)

# face20 and hands21 (wrong) are being reported by the
# Cloud API as the names of wrFace20 and hand21(correct),
# include as fix
JOINT_DEFINITIONS = {
    J25.name: J25,
    EXTENDED.name: EXTENDED,
    FACE20.name: FACE20,
    HAND21.name: HAND21,
    'face20': FACE20,
    'hands21': HAND21
}

JOINT_DEFINITION_DEFAULTS = {
    'hands': HAND21,
    'head': FACE20,
    'pose2d': J25,
    'pose3d_raw': J25,
    'pose3d_ik': EXTENDED
}
